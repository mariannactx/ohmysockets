<?php
require_once('WebSocketUser.php');

class User extends WebSocketUser
{
    //protected function setId(){}
}

?>