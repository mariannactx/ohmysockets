A Pen created at CodePen.io. You can find this one at https://codepen.io/gschier/pen/VKgyaY.

 This is a Mac keyboard made in HTML and CSS. There is some JavaScript to control the keys, but that's it.